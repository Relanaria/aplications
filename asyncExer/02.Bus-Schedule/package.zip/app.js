function solve() {
  let current = "depot";
  let nextStop = "depot";
  const departBtn = document.getElementById("depart");
  const arriveBtn = document.getElementById("arrive");
  const infoDisplay = document.querySelector("#info span");

  async function depart() {
    try {
      let url = `http://localhost:3030/jsonstore/bus/schedule/${nextStop}`;

      arriveBtn.disabled = false;
      departBtn.disabled = true;

      let response = await fetch(url);
      if (!response.ok) {
        arriveBtn.disabled = true;
        departBtn.disabled = true;
        infoDisplay.textContent = "Error";
      }

      let data = await response.json();
      infoDisplay.textContent = `Next stop ${data.name}`;
      current = data.name;
      nextStop = data.next;
    } catch (error) {
      arriveBtn.disabled = true;
      departBtn.disabled = true;
      infoDisplay.textContent = "Error";
    }
  }

  function arrive() {
    arriveBtn.disabled = true;
    departBtn.disabled = false;

    infoDisplay.textContent = `Ariving at ${current}`;
  }

  return {
    depart,
    arrive,
  };
}

let result = solve();
