function add(a, b) {
    return a + b;
}

function product(a, b) {
    return a * b;
}

export {
    add,
    product
}